const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/auth');
const { plaidClient, getInternalCategory } = require('../config/plaid');
const User = require('../models/User');
const BankAccount = require('../models/BankAccount');
const Transaction = require('../models/Transaction');

// @route   POST api/plaid/create-link-token
// @desc    Create Plaid link token
// @access  Private
router.post('/create-link-token', protect, async (req, res) => {
  try {
    const response = await plaidClient.createLinkToken({
      user: { client_user_id: req.user.id },
      client_name: 'FinSmart',
      products: ['transactions'],
      country_codes: ['US'],
      language: 'en'
    });
    res.json({ link_token: response.link_token });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error creating link token');
  }
});

// @route   POST api/plaid/set-access-token
// @desc    Exchange public token for access token
// @access  Private
router.post('/set-access-token', protect, async (req, res) => {
  try {
    const { public_token, institution_id, institution_name } = req.body;
    const response = await plaidClient.exchangePublicToken(public_token);

    const newAccount = new BankAccount({
      user: req.user.id,
      plaidItemId: response.item_id,
      plaidAccessToken: response.access_token,
      institutionName: institution_name,
      institutionId: institution_id
    });

    await newAccount.save();
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error exchanging token');
  }
});

// @route   GET api/plaid/accounts
// @desc    Get linked bank accounts
// @access  Private
router.get('/accounts', protect, async (req, res) => {
  try {
    const accounts = await BankAccount.find({ user: req.user.id });
    res.json(accounts);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching accounts');
  }
});

module.exports = router;